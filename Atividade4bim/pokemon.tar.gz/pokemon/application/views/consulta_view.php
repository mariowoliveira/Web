<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Pokémon GO</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


	<link rel="stylesheet" href="http://localhost/pokemon/assets/main.css">
</head>
<body>
	<div id="header">
			<?php
				if(null != $this->session->userdata('logado')) {
				}
				else{
					redirect(base_url("login"));
				}
			?>
	</div>	
	<img src="http://localhost/pokemon/assets/images/buba.png" class="img">
	<img src="http://localhost/pokemon/assets/images/pokemon.jpg" class="img">
	<img src="http://localhost/pokemon/assets/images/pokemongo2.png" class="img">
	<img src="http://localhost/pokemon/assets/images/pokemon.jpg" class="img">
	<img src="http://localhost/pokemon/assets/images/pikachu.png" class="img">
	<nav class="navbar navbar-default">

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
		<li id="central"><?php echo anchor(base_url("home") ,"Home");	?></li>
        <li id="central"><?php echo anchor(base_url("cadastro") ,"Cadastrar Pokémon"); ?></li>
        <li id="central" class="active"><?php echo anchor(base_url("") ,"Sair"); ?></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
	<table class="table">
    		<thead>
      		<tr>
        			<th>Nome do Pokémon</th>
        			<th>Tipo de Pokémon</th>
        			<th>Data de Captura</th>
					<th>Excluir</th>
					<th>Editar</th>
     			</tr>
    		</thead>
    		<tbody>
				<tr class="default">
					<?php
              			foreach($pokemon as $pok){
               				echo "<tr>";
                 			echo "<td>".$pok->Nome."</td>";
                 			echo "<td>".$pok->Tipo_Pokemon."</td>";
                  			echo "<td>".$pok->Data_Captura."</td>";
                  			echo "<td>".anchor('../consulta/deletar/'.$pok->id_pokemon, '<button type="button" class="btn btn-primary">Excluir</button>', 'id="$pok->id_pokemon"')."</td>";
                  			echo "<td>".anchor('../consulta/editar/'.$pok->id_pokemon, '<button type="button" class="btn btn-primary">Editar</button>', 'id="$pok->id_pokemon"')."</td>";
              			}
               		?>
           		</tr>
         	</tbody>
      </table>



</body>
</html>
