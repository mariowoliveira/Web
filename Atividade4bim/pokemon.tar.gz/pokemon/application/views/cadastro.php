	<title>Pokémon GO</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


	<link rel="stylesheet" href="http://localhost/pokemon/assets/main.css">
</head>
<body>
	<div id="header">
			<?php
				if(null != $this->session->userdata('logado')) {
				}
				else{
					redirect(base_url("login"));
				}
			?>
	</div>	
	<img src="http://localhost/pokemon/assets/images/buba.png" class="img">
	<img src="http://localhost/pokemon/assets/images/pokemon.jpg" class="img">
	<img src="http://localhost/pokemon/assets/images/pokemongo2.png" class="img">
	<img src="http://localhost/pokemon/assets/images/pokemon.jpg" class="img">
	<img src="http://localhost/pokemon/assets/images/pikachu.png" class="img">
	<nav class="navbar navbar-default">

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
		 <li id="central"><?php echo anchor(base_url("home") ,"Home");	?></li>
        <li id="central"><?php echo anchor(base_url("consulta") ,"Consultar Pokémon");	?></li>
        <li id="central" class="active"><?php echo anchor(base_url("") ,"Sair"); ?></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<fieldset>

<!-- Form Name -->
<legend class="formcad">Cadastrar Pokemon</legend>
<form name="formCadastro" class="formcad" enctype="multipart/form-data" method="POST" action="http://localhost/pokemon/index.php/Cadastro/cadastrar">
            <label class="input-group">Nome do Pokemon:</label>
                          <div class="input-group">
                              <span class="input-group-addon"><i class="fa fa-font"></i></span>
                              <input type="text" class="form-control" name="Nome" placeholder="Nome" required="">
                          </div>
                          <br>
                          <label class="input-group">Data da captura:</label>
                            <div class="input-group">

                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="text" class="form-control" name="Data_Captura" placeholder="AAAA-MM-DD" required="">
                            </div>
                            <br>
                            <div class="dropdown">
                              <label class="input-group">Tipo:</label>

                              <select data-toggle="dropdown" name="Tipo_Pokemon" class="btn btn-primary dropdown-toggle" required=""><span class="caret"></span>
                                    <ul class="dropdown-menu">
                                        <option value="" disabled selected hidden>Tipo</option>
                                        <option value="Verde">Verde</option>
                                        <option value="Laranja">Laranja</option>
                                        <option value="Vermelho">Vermelho</option>

                                    </ul>
                              </select>

                            </div>
                            <br>
                            <div class="form-group">
                                <!-- Button -->
                                <div class="col-sm-12 controls">

                                        <button type="submit" href="#" class="btn btn-success" id="but"><i class="fa fa-sign-in"></i> Cadastrar</button>
                                        <a  class="btn btn-danger" href="http://localhost/pokemon/index.php/Home" >Cancelar</a></li></th><br />


                                </div>
                            </div>

                        </form>
</fieldset>

</div>
