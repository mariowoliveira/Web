<?php defined('BASEPATH') OR exit('No direct script access allowed') ;
 class Cadastro extends CI_Controller{
 public $pokemon;
	public function __construct () {
		parent::__construct();
      $this->load->library("session");
		}
		 public function index () {
		 $this->load->helper('text');
		 $this->load->view('cadastro');
		 }
     public function cadastrar(){
             $this->load->helper(array("form", "url"));
             $this->load->database();
             //Pega campos do formulario
             $data['Nome'] = $this->input->post('Nome');
             $data['Data_Captura'] = $this->input->post('Data_Captura');
             $data['Tipo_Pokemon'] = $this->input->post('Tipo_Pokemon');
             //insere no banco de dados
             if ($this->db->insert('pokemon',$data)) {
               redirect(base_url("Home"));
             }
       }
}
