<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Consulta extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model("PokemonModel", "pokemonmodel");
        $this->pokemon = $this->pokemonmodel->exibirPokemon();
    }
	
	public function index(){
		$this->load->helper('text');
		$dados['pokemon'] = $this->pokemon;		
		$this->load->view('consulta_view', $dados);	
	}
	
	public function deletar(){
		 $id = $this->uri->segment(3);		 
		 $this->load->model('pokemonmodel');
   	 $this->pokemonmodel->deletarPokemon($id);
  		 redirect(base_url('consulta')); 		
	}	
}
